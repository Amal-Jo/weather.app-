package com.parse.finalsem;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private Handler waitHandler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        waitHandler.postDelayed(new Runnable() {
            @Override
            public void run() {

                try {
                    Intent intent = new Intent(MainActivity.this,FirstPage.class);
                    startActivity(intent);

                    //Let's Finish Splash Activity since we don't want to show this when user press back button.
                    finish();

                }catch (Exception ignored){
                    ignored.printStackTrace();
                }

            }
        },3000);
    }

    @Override public void onDestroy(){
        super.onDestroy();

        //Remove all the callbacks otherwise navigation will execute even after activity is killed or closed.
        waitHandler.removeCallbacksAndMessages(null);
    }
}
