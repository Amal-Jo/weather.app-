package com.parse.finalsem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class FinalActivity extends AppCompatActivity {
    TextView minimumTemp;
    TextView maxTemp;
    TextView cityName;
    String Locality;
    TextView temperature;
    TextView statusDetails;
    TextView pressure;
    TextView humidity;
    TextView sunRise;
    TextView sunSet;
    TextView wind;
    TextView visibility;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final);


        temperature = (TextView)findViewById(R.id.temp);

        minimumTemp = (TextView)findViewById(R.id.temp_min);

        maxTemp = (TextView)findViewById(R.id.temp_max);

        cityName = (TextView)findViewById(R.id.address);


        statusDetails = (TextView)findViewById(R.id.status);

        pressure = (TextView)findViewById(R.id.pressure);

        humidity = (TextView)findViewById(R.id.humidity);

        sunRise = (TextView)findViewById(R.id.sunrise);

        sunSet = (TextView)findViewById(R.id.sunset);

        wind = (TextView)findViewById(R.id.wind);

        visibility =(TextView)findViewById(R.id.visibility);

        Bundle bundle = getIntent().getExtras();

        String cityResult = bundle.getString("enterCity");

        Locality = bundle.getString("Locality");

        cityName.setText(Locality );

        Log.i("locality", String.valueOf(Locality));

        DownloadTask task = new DownloadTask();

        if (Locality!= null) {

            task.execute("https://openweathermap.org/data/2.5/weather?q=" + Locality + "&appid=b6907d289e10d714a6e88b30761fae22");

        }else{

            cityName.setText(cityResult);

           // InputMethodManager mgr = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            //mgr.hideSoftInputFromWindow(cityName.getWindowToken(), 0);


            try {
                String encodedCityName = URLEncoder.encode(cityResult, "UTF-8");

                //DownloadTask task = new DownloadTask();
                task.execute("https://openweathermap.org/data/2.5/weather?q=" + encodedCityName + "&appid=b6907d289e10d714a6e88b30761fae22");


            } catch (UnsupportedEncodingException e) {

                e.printStackTrace();

            }


        }

    }

    public class DownloadTask extends AsyncTask<String, Void, String>{

        @Override
        protected String doInBackground(String... urls) {

            String result = "";
            URL url;
            HttpURLConnection urlConnection = null;

            try {
                url = new URL(urls[0]);

                urlConnection = (HttpURLConnection) url.openConnection();

                InputStream inputStream = urlConnection.getInputStream();

                InputStreamReader reader = new InputStreamReader(inputStream);

                int weatherData = reader.read();

                while (weatherData != -1) {

                    char current = (char) weatherData;

                    result += current;

                    weatherData = reader.read();
                }

                return result;

            } catch (MalformedURLException e) {
                e.printStackTrace();
            }

            catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            String temp;


            try {
                // We create out JSONObject from the data
                JSONObject jsonObject = new JSONObject(result);

                String nameInfo = jsonObject.getString("name");

                String tempInfo = jsonObject.getString("main");

                String sunInfo = jsonObject.getString("sys");

                String windInfo = jsonObject.getString("wind");

                // String visibleInfo = jsonObject.getString("visibility");
                double visibleInfo = Double.parseDouble(jsonObject.getString("visibility"));

                int visibleInfoInMeter = (int) (visibleInfo/1000);

                Log.i("nameContent",nameInfo);

                Log.i("Temp content",tempInfo);

                Log.i("sun content",sunInfo);


                Log.i("wind content",windInfo);

                Log.i("visible content", String.valueOf(visibleInfo));

               // cityName.setText(Locality+ sun.getString("country"));


                JSONObject mainPart = new JSONObject(tempInfo);

                temp = mainPart.getString("temp");

                String mTemp =mainPart.getString("temp_min");

                String mxTemp = mainPart.getString("temp_max");

                String tPressure = mainPart.getString("pressure");

                String tHumidity = mainPart.getString("humidity");


                temperature.setText(temp+ "°C");

                minimumTemp.setText(mTemp + "°C");

                maxTemp.setText(mxTemp + "°C");

                pressure.setText(tPressure);

                humidity.setText(tHumidity+"%");

                Log.i("min temp", mTemp);

                Log.i("max temp",mxTemp );

                JSONObject sunPart = new JSONObject(sunInfo);

                String countryName = sunPart.getString("+ country");

                String sunrise =sunPart.getString("sunrise");
                long unixSeconds =Long.parseLong(sunrise);

               /* long unixSeconds =Long.parseLong(sunrise);
                // convert seconds to milliseconds
                Date date = new java.util.Date(unixSeconds*1000L);
                 // the format of your date
                SimpleDateFormat sdf = new java.text.SimpleDateFormat("HH:mm");
                // give a timezone reference for formatting
                sdf.setTimeZone(java.util.TimeZone.getTimeZone("GMT-4"));

                String formattedDate = sdf.format(date);
                //System.out.println(formattedDate);
                String requiredSunrise = formattedDate;*/


                //sunRise.setText(requiredSunrise+"AM");
                sunRise.setText(new SimpleDateFormat("hh:mm a", Locale.ENGLISH).format(new Date(unixSeconds * 1000)));
                Log.i("sunRise content",new SimpleDateFormat("hh:mm a", Locale.ENGLISH).format(new Date(unixSeconds * 1000)));

                String sunset =sunPart.getString("sunset");


                long sUnixSeconds =Long.parseLong(sunset);

                sunSet.setText(new SimpleDateFormat("hh:mm a", Locale.ENGLISH).format(new Date(sUnixSeconds * 1000)));


                JSONObject windPart = new JSONObject(windInfo);

                String windspeed = windPart.getString("speed");

                //double windspeedDouble = Double.parseDouble(jsonObject.getString("speed"));


                wind.setText(windspeed+"km/h");

                visibility.setText((String.valueOf(visibleInfoInMeter)) +"KM");




                String weatherInfo = jsonObject.getString("weather");

                Log.i("Weather content", weatherInfo);

                JSONArray arr = new JSONArray(weatherInfo);

                for (int i = 0; i < arr.length(); i++) {

                    JSONObject jsonPart = arr.getJSONObject(i);

                    String main = "";
                    String description = "";

                    main = jsonPart.getString("main");
                    description = jsonPart.getString("description");

                    statusDetails.setText(description);

                }

            } catch (JSONException e) {
                e.printStackTrace();
            }



        }
    }



}