package com.parse.finalsem;

import android.app.DownloadManager;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;


public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String TAG ="DatabaseHelper";
    private static final String DATABASE_NAME = "Database";

    private static final String TABLE_NAME = "Location_Details";
    private static final String COL1 ="LATITUDE";
    private static final String COL2 ="LONGITUDE";

    public DatabaseHelper(Context context){
        super(context,DATABASE_NAME,null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        String createTable = "CREATE TABLE Location_Details ( LATITUDE TEXT,LONGITUDE TEXT )";
        sqLiteDatabase.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        String createTable = "DROP TABLE IF EXISTS " + TABLE_NAME;
        sqLiteDatabase.execSQL(createTable);


    }

    public boolean addData (Double latitude,Double longitude) {

        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL1, latitude);
        contentValues.put(COL2, longitude);
        Log.d(TAG, "adding data" + latitude + "and" + longitude + "to" + TABLE_NAME);
        sqLiteDatabase.insert(TABLE_NAME,null,contentValues);
        sqLiteDatabase.close();
        return true;
    }



}
