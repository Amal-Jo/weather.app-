package com.parse.finalsem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class searchCityActivity extends AppCompatActivity {

    EditText serachCity;
    Button search;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_city);

        serachCity = (EditText)findViewById(R.id.enterTextview);

        search = (Button)findViewById(R.id.serachCityButton);

        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i = new Intent(getApplicationContext(),FinalActivity.class);

                i.putExtra("enterCity",serachCity.getText().toString());
                startActivity(i);
            }
        });

    }
}
