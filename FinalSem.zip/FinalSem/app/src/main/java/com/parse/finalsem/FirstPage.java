package com.parse.finalsem;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class FirstPage extends AppCompatActivity {

    Button DetectLocation;

    Button searchByCity;

    LocationManager locationManager;
    boolean gps_enabled = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_page);

        DetectLocation = (Button)findViewById(R.id.DetectButton);
        DetectLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Log.i("click","detect  button clicked");

                if( gps_enabled = true) {

                    Intent i = new Intent(FirstPage.this, LocationMapsActivity.class);
                    startActivity(i);
                }
                else{
                   CheckGpsStatus() ;

                }


            }
        });

        searchByCity = (Button)findViewById(R.id.searchByCityName);

        searchByCity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(),searchCityActivity.class);
                startActivity(i);
            }
        });
    }

   private void CheckGpsStatus() {

        Context context = getApplicationContext();
        locationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);

        try {
            gps_enabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
        } catch (Exception ex) {
            ex.printStackTrace();
        }


        if (!gps_enabled) {

            Log.i("gps","checking...");
            // notify user

            new AlertDialog.Builder(this)

                    .setTitle("Alert")
                    .setMessage("GPS is disabled, So please enable it.")
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            //startActivityForResult(new Intent(android.provider.Settings.ACTION_SETTINGS), 1);
                            startActivity( new Intent(Settings. ACTION_LOCATION_SOURCE_SETTINGS )) ;

                        }
                    })

                    .setNegativeButton("Cancel", null)
                    .show();


        }
    }
}

